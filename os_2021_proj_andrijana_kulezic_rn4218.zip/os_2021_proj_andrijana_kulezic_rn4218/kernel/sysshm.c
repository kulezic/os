#include "types.h"
#include "defs.h"
#include "param.h"
#include "stat.h"
#include "mmu.h"
#include "proc.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fcntl.h"
#include "shm.h"
#include "memlayout.h"

static int
argfd(int n, int *pfd, struct shm **ps)
{
	int fd;
	struct shm *s;

	if(argint(n, &fd) < 0)
		return -1;
	if(fd < 0 || fd >= NOSHM || (s=myproc()->oshm[fd]) == 0)
		return -1;
	if(pfd)
		*pfd = fd;
	if(ps)
		*ps = s;
	return 0;
}


static int
shmfdalloc(struct shm *s)
{
    int fd;
    struct proc *curproc = myproc();

    for(fd = 0; fd < NOSHM; fd++){
        if(curproc->oshm[fd] == 0){
            curproc->oshm[fd] = s;
            return fd;
        }
    }
    return -1;
}

int
sys_shm_open(void){
    char* name;
    struct shm *s;
    int fd;
    if(argstr(0, &name) < 0)
        return -1;
    
    if((s = shmopen(name)) == 0 || (fd = shmfdalloc(s)) < 0){
        return -1;
    }
    return fd;
}


int
sys_shm_trunc(void){
    struct shm *s;
    int size;
    
    if(argfd(0, 0, &s) < 0 || argint(1, &size) < 0)
        return -1;
    
    return shmtrunc(s, size);

}


int
sys_shm_map(void){
    struct shm *s;
    int perm, pt, fd;
    uint first, last;
    
    void **a;
    
    if(argfd(0, &fd, &s) < 0 || argint(1, (void *)&a) < 0 || argint(2, &perm) < 0)
        return -1;
    
    struct proc *curproc = myproc();
    

    if(perm != O_RDWR && perm != O_RDONLY)
        return -1;
   
    if(perm == O_RDWR){
        perm = PTE_W;
    }else perm = 0;
    
    last = PGROUNDDOWN(curproc->last_mapped - 1);
    first = PGROUNDDOWN(last - s->size);
    
    
    pt = shmmap(s, curproc->pgdir, perm, first, last);
    
    if(pt < 0)
        return -1;
    
    curproc->last_mapped = pt;
    
    
    *a = (char *)first;
    
    
    return 0;
    
}


int
sys_shm_close(void)
{
    int fd;
    struct shm *s;

    if(argfd(0, &fd, &s) < 0)
        return -1;
    
    struct proc *curproc = myproc();
    
    curproc->oshm[fd] = 0;
    shmclose(s, curproc->pgdir);
    
    return 0;
}

