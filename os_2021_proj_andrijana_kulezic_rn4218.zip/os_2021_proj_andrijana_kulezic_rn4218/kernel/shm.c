#include "types.h"
#include "defs.h"
#include "param.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "shm.h"
#include "mmu.h"
#include "memlayout.h"


struct {
	struct spinlock lock;
	struct shm shm[NOSHM];
} shmtable;


//int nextshmid = 1;

void
shminit(void)
{
	initlock(&shmtable.lock, "shmtable");
}

void
clear_addrs(struct shm *s){
    for (int i = 0; i < 32; i++) {
        s->addrs[i] = 0;
    }
}

void
clear_name(struct shm *s){
    for (int i = 0; i < 16; i++) {
        s->name[i] = 0;
    }
}


struct shm*
shmopen(char *name)
{
	struct shm *s;

	acquire(&shmtable.lock);
	for(s = shmtable.shm; s < shmtable.shm + NOSHM; s++){
		if(!strncmp(s->name, name, strlen(name))){
			if(s->ref < 0)
                panic("shmopen");
            s->ref++;
			release(&shmtable.lock);
			return s;
		}
	}
    
    for(s = shmtable.shm; s < shmtable.shm + NOSHM; s++){
        if(s->ref == 0){
            safestrcpy(s->name, name, sizeof(s->name));
            s->ref = 1;
            s->size = 0;
            clear_addrs(s);
            release(&shmtable.lock);
            return s;
        }
    }
    
	release(&shmtable.lock);
	return 0;
}



void
shmclose(struct shm *s, pde_t *pgdir)
{
    
	acquire(&shmtable.lock);
	if(s->ref < 0)
		panic("shmclose");
    
    s->ref -= 1;
    
    if (s->ref > -1) {
        release(&shmtable.lock);
        return;
    }
    
    for (int i = 0; i < TNOSHM; i++) {
        if(s->addrs[i] != 0){
            uint a = PGROUNDDOWN(s->addrs[i]);
            char *pa = P2V(a);
            kfree(pa);
        }
    }
    
	
    s->name[0] = 0;
    s->ref = 0;
    s->size = 0;
    s->addrs[0] = 0;
    
	release(&shmtable.lock);

}


int
shmtrunc(struct shm *s, int size){
    
    int rtn;
    
    acquire(&shmtable.lock);
    
    if(size > PGSIZE*TNOSHM){
        release(&shmtable.lock);
        return -1;
    }
    if (s->size > 0 || size == 0){
        release(&shmtable.lock);
        return 0;
    }
    
    char *mem;
    
    int j = 0;
    
    for (int i = 0; i < size; i+=PGSIZE) {
        mem = kalloc();
        if(mem == 0){
            cprintf("shm trunc out of memory\n");
            release(&shmtable.lock);
            return -1;
        }
        memset(mem, 0, PGSIZE);
        s->addrs[j] = V2P(mem)| PTE_P | PTE_U;
        j++;
    }
    
    s->size = size;
    
    rtn = s->size;
    
    
    release(&shmtable.lock);
    
    return rtn;
    
}

struct shm*
shmdup(struct shm *s)
{
    acquire(&shmtable.lock);
    if(s->ref < 1)
        panic("shmdup");
    s->ref += 1;
    release(&shmtable.lock);
    return s;
}

int
shmmap(struct shm *s, pde_t *pgdir, int perm, uint first, uint last){
    uint a, i, rtn;
    pte_t *pte;
    a = first;
    i = 0;
    rtn = first;
    
    
    acquire(&shmtable.lock);
    
    for(;;){
        if((pte = walkpgdir2(pgdir, (char*)a, 1)) == 0){
            release(&shmtable.lock);
            return -1;
        }
        if(*pte & PTE_P)
            panic("remap shm");
        
        *pte = s->addrs[i] | perm;
        if(a==last) break;
        a += PGSIZE;
        i++;
    }
    
    
    release(&shmtable.lock);
    return rtn;
}


int
shmmap_pg(pde_t *pgdir, uint va, uint pa, int perm){
    pte_t *pte;
    
    if((pte = walkpgdir2(pgdir, (char*)va, 1)) == 0){
        return -1;
    }
    if(*pte & PTE_P)
        panic("remap shm");
    
    *pte = pa | perm | PTE_P;
    
    return 0;
}
/*
void freeshm(struct shm *s){
    for (int i = 0; i < TNOSHM; i++) {
        if(s->addrs[i]){
            char *pa = P2V(s->addrs[i]);
            kfree(pa);
        }
    }
}
*/
