#define FG 0
#define BG 1
#define ALL 2
#define RESET 3
