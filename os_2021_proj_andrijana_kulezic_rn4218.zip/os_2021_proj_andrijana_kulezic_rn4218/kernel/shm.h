#define NOSHM 64
#define TNOSHM 32

struct shm {
    char name[16];
    uint addrs[32];
    int size;
    int ref;
};

