// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "shm.h"
#include "x86.h"
#include "color.h"

static void consputc(int);

static int panicked = 0;

static struct {
	struct spinlock lock;
	int locking;
} cons;

static void
printint(int xx, int base, int sign)
{
	static char digits[] = "0123456789abcdef";
	char buf[16];
	int i;
	uint x;

	if(sign && (sign = xx < 0))
		x = -xx;
	else
		x = xx;

	i = 0;
	do{
		buf[i++] = digits[x % base];
	}while((x /= base) != 0);

	if(sign)
		buf[i++] = '-';

	while(--i >= 0)
		consputc(buf[i]);
}

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
	int i, c, locking;
	uint *argp;
	char *s;

	locking = cons.locking;
	if(locking)
		acquire(&cons.lock);

	if (fmt == 0)
		panic("null fmt");

	argp = (uint*)(void*)(&fmt + 1);
	for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
		if(c != '%'){
			consputc(c);
			continue;
		}
		c = fmt[++i] & 0xff;
		if(c == 0)
			break;
		switch(c){
		case 'd':
			printint(*argp++, 10, 1);
			break;
		case 'x':
		case 'p':
			printint(*argp++, 16, 0);
			break;
		case 's':
			if((s = (char*)*argp++) == 0)
				s = "(null)";
			for(; *s; s++)
				consputc(*s);
			break;
		case '%':
			consputc('%');
			break;
		default:
			// Print unknown % sequence to draw attention.
			consputc('%');
			consputc(c);
			break;
		}
	}

	if(locking)
		release(&cons.lock);
}

void
panic(char *s)
{
	int i;
	uint pcs[10];

	cli();
	cons.locking = 0;
	// use lapiccpunum so that we can call panic from mycpu()
	cprintf("lapicid %d: panic: ", lapicid());
	cprintf(s);
	cprintf("\n");
	getcallerpcs(&s, pcs);
	for(i=0; i<10; i++)
		cprintf(" %p", pcs[i]);
	panicked = 1; // freeze other CPU
	for(;;)
		;
}

#define BACKSPACE 0x100
#define CRTPORT 0x3d4
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory
static ushort term_content[6][25*80];
static int term_pos[6] = {0,0,0,0,0,0};
static int def_col[6] = {0x0700, 0x1700, 0x2700, 0x3000, 0x4700, 0x5700};
static int term_col[6] = {0x0700, 0x1700, 0x2700, 0x3000, 0x4700, 0x5700};
static int curr = 0;
static int first = 1;


void wrt_name(){
    crt[25*80-1] = ((curr + 49)&0xff) | term_col[curr] ;
    crt[25*80-2] = ('y' &0xff)| term_col[curr] ;
    crt[25*80-3] = ('t' &0xff)| term_col[curr] ;
    crt[25*80-4] = ('t' &0xff)| term_col[curr] ;
}

void clearbk (){
    for (int i = 0; i < 25*80; i++) {
        crt[i] = (' ' & 0xff) | term_col[curr];
    }
}

void rewrite(){
    for(int i = 0; i < term_pos[curr]; i++){
        crt[i] = (term_content[curr][i] & 0xff) | term_col[curr];
    }
}

void setpos(){
    outb(CRTPORT, 14);
    outb(CRTPORT+1, term_pos[curr]>>8);
    outb(CRTPORT, 15);
    outb(CRTPORT+1, term_pos[curr]);
    crt[term_pos[curr]] = (' '& 0xff)| term_col[curr];
}

void save_content(){
    for (int i = 0; i < term_pos[curr]; i++){
        term_content[curr][i] = crt[i];
    }
}

void
swtch_term(int change){
    save_content();
    curr = change;
    clearbk();
    rewrite();
    setpos();
    wrt_name();
}




static void
cgaputc(int c)
{
	int pos;

	// Cursor position: col + 80*row.
	outb(CRTPORT, 14);
	pos = inb(CRTPORT+1) << 8;
	outb(CRTPORT, 15);
	pos |= inb(CRTPORT+1);
    
    if(pos == 1) wrt_name();

	if(c == '\n')
		pos += 80 - pos%80;
	else if(c == BACKSPACE){
		if(pos > 0) --pos;
    } else{
        term_content[curr][term_pos[curr]++] = c;
        crt[pos++] = (c&0xff) | term_col[curr];  // black on white
    }
	if(pos < 0 || pos > 25*80)
		panic("pos under/overflow");

	if((pos/80) >= 24){  // Scroll up.
		memmove(crt, crt+80, sizeof(crt[0])*23*80);
		pos -= 80;
		memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
        
        for (int i = 80*23; i < 24*80; i++) {
            crt[i] = (' ' & 0xff) | term_col[curr];
        }
	}

	outb(CRTPORT, 14);
	outb(CRTPORT+1, pos>>8);
	outb(CRTPORT, 15);
	outb(CRTPORT+1, pos);
    crt[pos] = (' '& 0xff)| term_col[curr];
    term_pos[curr] = pos;
}

void
consputc(int c)
{
	if(panicked){
		cli();
		for(;;)
			;
	}

	if(c == BACKSPACE){
		uartputc('\b'); uartputc(' '); uartputc('\b');
	} else
		uartputc(c);
	cgaputc(c);
}

#define INPUT_BUF 128
struct input{
	char buf[INPUT_BUF];
	uint r;  // Read index
	uint w;  // Write index
	uint e;  // Edit index
};

static struct input t_ipt[6];

#define C(x)  ((x)-'@')  // Control-x
#define A(x)  ((x)-'0')  // Alt-x

void
mvrow(int term){
    memmove(term_content[term], term_content[term]+80, sizeof(term_content[term][0])*23*80);
    term_pos[term] -= 80;
    memset(term_content[term]+term_pos[term], 0, sizeof(term_content[term])*(24*80 - term_pos[term]));
}

void
consoleintr(int (*getc)(void))
{
	int c, doprocdump = 0;

	acquire(&cons.lock);
	while((c = getc()) >= 0){
		switch(c){
		case C('P'):  // Process listing.
			// procdump() locks cons.lock indirectly; invoke later
			doprocdump = 1;
			break;
		case C('U'):  // Kill line.
			while(t_ipt[curr].e != t_ipt[curr].w &&
                  t_ipt[curr].buf[(t_ipt[curr].e-1) % INPUT_BUF] != '\n'){
                t_ipt[curr].e--;
				consputc(BACKSPACE);
			}
			break;
		case C('H'): case '\x7f':  // Backspace
			if(t_ipt[curr].e != t_ipt[curr].w){
                t_ipt[curr].e--;
				consputc(BACKSPACE);
			}
			break;
                
            case A('1'):
                if(curr == 0) break;
                swtch_term(0);
                break;
            case A('2'):
                if(curr == 1) break;
                swtch_term(1);
                break;
            case A('3'):
                if(curr == 2) break;
                swtch_term(2);
                break;
            case A('4'):
                if(curr == 3) break;
                swtch_term(3);
                break;
            case A('5'):
                if(curr == 4) break;
                swtch_term(4);
                break;
            case A('6'):
                if(curr == 5) break;
                swtch_term(5);
                break;
                
		default:
			if(c != 0 && t_ipt[curr].e-t_ipt[curr].r < INPUT_BUF){
				c = (c == '\r') ? '\n' : c;
                t_ipt[curr].buf[t_ipt[curr].e++ % INPUT_BUF] = c;
				consputc(c);
				if(c == '\n' || c == C('D') || t_ipt[curr].e == t_ipt[curr].r+INPUT_BUF){
                    t_ipt[curr].w = t_ipt[curr].e;
					wakeup(&t_ipt[curr].r);
				}
			}
			break;
		}
	}
	release(&cons.lock);
	if(doprocdump) {
		procdump();  // now call procdump() wo. cons.lock held
	}
}


int
consoleread(struct inode *ip, char *dst, int n)
{
	uint target;
	int c;

	iunlock(ip);
	target = n;
	acquire(&cons.lock);
	while(n > 0){
		while(t_ipt[curr].r == t_ipt[curr].w){
			if(myproc()->killed){
				release(&cons.lock);
				ilock(ip);
				return -1;
			}
			sleep(&t_ipt[ip->minor - 1].r, &cons.lock);
		}
		c = t_ipt[curr].buf[t_ipt[curr].r++ % INPUT_BUF];
		if(c == C('D')){  // EOF
			if(n < target){
				// Save ^D for next time, to make sure
				// caller gets a 0-byte result.
                t_ipt[curr].r--;
			}
			break;
		}
		*dst++ = c;
		--n;
		if(c == '\n')
			break;
	}
	release(&cons.lock);
	ilock(ip);

	return target - n;
}

int
consolewrite(struct inode *ip, char *buf, int n)
{
	int i;

	iunlock(ip);
	acquire(&cons.lock);
    
    if(first){
        wrt_name();
        first = 0;
    }
    
    if(ip->minor -1 == curr){
        for(i = 0; i < n; i++){
            consputc(buf[i] & 0xff);
        }
    }else{
        int oth = ip->minor-1;
        for(i = 0; i < n; i++){
            if ((term_pos[oth]/80) >= 24) mvrow(oth);
            if(buf[i] == '\n'){
                term_pos[oth] += 80 - term_pos[oth]%80;
                continue;
            }
            term_content[oth][term_pos[oth]++] = buf[i];
        }
    }
    
	release(&cons.lock);
	ilock(ip);

	return n;
}



void
consoleinit(void)
{
	initlock(&cons.lock, "console");

	devsw[CONSOLE].write = consolewrite;
	devsw[CONSOLE].read = consoleread;
	cons.locking = 1;

	ioapicenable(IRQ_KBD, 0);
}


sys_color(void){
    int color, mode;
    
    if(argint(0, &color) < 0 || argint(1, &mode) < 0)
        return -1;
    
    if(mode == ALL){
        (term_col[curr] & 0x0000) | color;
    }else if(mode == FG){
        (term_col[curr] & 0xF000) | color;
    }else if(mode == BG){
        (term_col[curr] & 0x0F00) | color;
    }else if(mode == RESET){
        term_col[curr] = def_col[curr];
    }else{
        return -1;
    }
    
    save_content();
    clearbk();
    rewrite();
    
    return 0;
    
}
