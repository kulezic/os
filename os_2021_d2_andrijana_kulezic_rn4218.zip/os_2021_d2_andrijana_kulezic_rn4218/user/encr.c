#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user.h"
#include "kernel/fs.h"

char help[] = {"\nUse this program to encrypt files written on the disk.\nUsage: encr [OPTION] ...  [FILENAME]...\n\nCommand line options:\n   -h, --help: Show help prompt\n   -a, --encrypt-all: Encrypt all files in CWD with current key\n"};


void encrypt(char *filename){
    int fd;
    
    fd = open(filename, O_RDWR);
    
    if (fd < 0){
        fprintf(2, "Failed to open file %s\n", filename);
        return;
    }
    
    int e = encr(fd);
    
    if (e >= 0 ) printf("Sucessful: file %s is encrypted\n", filename);
    if (e == -1) fprintf(2, "Failed to encrypt: key is not set\n");
    if (e == -2) fprintf(2, "Failed to encrypt: unable to encrypt T_DEV files\n");
    if (e == -3) fprintf(2, "Failed to encrypt: file %s is already encrypted\n", filename);
    if (e == -4) fprintf(2, "Failed to encrypt: unable to encrypt file %s\n", filename);
    
    close(fd);
    
    return;
}

void
encrypt_all(){
    
    int fd;
    struct dirent de;
    
    if((fd = open(".", 0)) < 0){
        fprintf(2, "Failed to opencurrent directory\n");
        close(fd);
        return;
    }
    
    
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
        if(de.inum == 0)
            continue;
        encrypt(de.name);
    }
    
    close(fd);
    
    return;
}


int
main(int argc, char *argv[])
{
	int i;
    
    if (argc < 2) printf("%s", help);

    for(i = 1; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("%s", help);
            break;
        }
        else if (strcmp(argv[i], "-a") == 0 || strcmp(argv[i], "--encrypt-all") == 0) {
            encrypt_all();
            break;
        }else{
            encrypt(argv[i]);
        }
    }
    
    
    exit();
}
