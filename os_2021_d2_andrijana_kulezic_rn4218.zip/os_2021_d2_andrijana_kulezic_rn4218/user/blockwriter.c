#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user.h"

char help[] = {"\nUse this program to create big file filled with sentence: ANJA JE SUPER !!!  \nDefault filename: long.txt \nDefault blocks: 150\nUsage: blockwriter [OPTION] ...\n\nCommand line options:\n   -h, --help: Show help prompt\n   -b, --blocks: Number of blocks to write\n   -o, --output-file: Set output filename\n"};
char letters[] = {"ANJA JE SUPER !!! "};
int nletters = 18;



void blockwriter(char *filename, int nblocks){
    int fd, i, j;
    
    fd = open(filename, O_CREATE | O_RDWR);
    
    if(fd >= 0) {
            printf("Successful: file %s is created\n", filename);
        } else {
            fprintf(2, "Failed to create %s file\n", filename);
            exit();
        }
    
    for (i = 1; i <= nblocks; i++) {
        char buf[512];
        for (j = 0; j < 512; j++) {
            buf[j] = letters[j%nletters];
        }
        if(write(fd, buf, 512) != 512){
            fprintf(2, "Failed to write block number %d to file %s\n",i, filename);
            exit();
        }
        printf("Successful: block %d is written to file %s\n",i, filename);
    }
    
    
    close(fd);
    exit();
}


int
main(int argc, char *argv[])
{
	int i;
    char filename[] = {"long.txt"};
    int nblocks = 150;

    for(i = 1; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("%s", help);
            exit();
        }
        if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--output-file") == 0) {
            i+=1;
            safestrcpy(filename, argv[i], strlen(argv[i]) + 1);
        }
        if (strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "--blocks") == 0) {
            i+=1;
            nblocks = atoi(argv[i]);
        }
    }
    
    blockwriter(filename, nblocks);
    
    exit();
}
