#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user.h"
#include "kernel/fs.h"

char help[] = {"\nUse this program to decrypt files written on the disk.\nUsage: decr [OPTION] ...  [FILENAME]...\n\nCommand line options:\n   -h, --help: Show help prompt\n   -a, --decrypt-all: Decrypt all files in CWD with current key\n"};


void decrypt(char *filename){
    int fd;
    
    fd = open(filename, O_RDWR);
    
    if (fd < 0){
        fprintf(2, "Failed to open file %s\n", filename);
        return;
    }
    
    int d = decr(fd);
    
    if (d >= 0 ) printf("Sucessful: file %s is decrypted\n", filename);
    if (d == -1) fprintf(2, "Failed to decrypt: key is not set\n");
    if (d == -2) fprintf(2, "Failed to decrypt: unable to decrypt T_DEV files\n");
    if (d == -3) fprintf(2, "Failed to decrypt: file %s is already decrypted\n", filename);
    if (d == -4) fprintf(2, "Failed to decrypt: unable to decrypt file %s\n", filename);
    
    close(fd);
    
    return;
}

void decrypt_all(){
    int fd;
    struct stat st;
    struct dirent de;
    
    if((fd = open(".", 0)) < 0){
        fprintf(2, "Failed to open current directory\n");
        return;
    }
    
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
        if(de.inum == 0)
            continue;
        decrypt(de.name);
    }
    
    close(fd);
    
    return;
}


int
main(int argc, char *argv[])
{
    int i;
    
    if (argc < 2) printf("%s", help);

    for(i = 1; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("%s", help);
            break;
        }
        else if (strcmp(argv[i], "-a") == 0 || strcmp(argv[i], "--decrypt-all") == 0) {
            decrypt_all();
            break;
        }else{
            decrypt(argv[i]);
        }
    }
    
    
    exit();
}
