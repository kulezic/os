#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

char help[] = {"\nUse this program to set the current active key.\nAfter setting the key you can use encr and decr with that key.\nUsage: setkey [OPTION] ...  [KEY]\n\nCommand line options:\n   -h, --help: Show help prompt\n   -s, --secret: Enter the key via STDIN. Hide the key while entering it.\n"};
char buf[128];

void
setsecret(){
    int fd = 0;
    int key = 0;
    int n;
    
    printf("Enter secret key: ");
    
    setecho(0);
    
    if ((n = read(fd, buf, sizeof (buf))) < 0) {
        fprintf(2, "Failed to read from STDIN\n");
        return;
    }
    key = atoi(buf);
    
    setecho(1);
    
    if (key == 0 && buf[0] != '0') {
        fprintf(2, "Invalid key\n");
        return;
    }
    
    setkey(key);
    return;
}

int
main(int argc, char *argv[])
{
	int i;
    
    if (argc > 2) fprintf(2, "You can set only one value for the key\n");

    for(i = 1; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("%s", help);
            break;
        }
        if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--secret") == 0) {
            setsecret();
            break;
        }
        
        
        int key = atoi(argv[i]);
        if (key == 0 && argv[i] != '0') {
            fprintf(2, "Invalid key\n");
            break;
        }
        setkey(key);
    }
	
    exit();
}
